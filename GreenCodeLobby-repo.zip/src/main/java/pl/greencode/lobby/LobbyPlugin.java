package pl.greencode.lobby;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.ChunkGenerator.BiomeGrid;
import org.bukkit.generator.ChunkGenerator.ChunkData;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class LobbyPlugin extends JavaPlugin implements CommandExecutor, Listener {

    private static final String PERMISSION = "greencode.admin";
    private static final String WORLD_PREFIX = "tryb_";
    private NamespacedKey compassKey;
    private final Map<String, ModeCommand> registered = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        compassKey = new NamespacedKey(this, "tryb-kompas");

        getCommand("greencode-lobby").setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);

        // Po restarcie odtworz swiaty i komendy zapisane w configu
        ConfigurationSection sec = getConfig().getConfigurationSection("tryby");
        if (sec != null) {
            for (String name : sec.getKeys(false)) {
                String worldName = sec.getString(name);
                if (worldName == null) continue;
                createVoidWorld(worldName);
                registerModeCommand(name, worldName);
            }
        }
    }

    // ===================== KOMENDY =====================

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission(PERMISSION)) {
            s.sendMessage(ChatColor.RED + "Brak uprawnien.");
            return true;
        }
        if (args.length == 0) {
            sendHelp(s);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "stworz" -> {
                if (args.length < 2) { s.sendMessage(ChatColor.RED + "Uzycie: /greencode-lobby stworz <nazwa>"); return true; }
                createMode(s, args[1].toLowerCase());
            }
            case "usun" -> {
                if (args.length < 2) { s.sendMessage(ChatColor.RED + "Uzycie: /greencode-lobby usun <nazwa>"); return true; }
                removeMode(s, args[1].toLowerCase());
            }
            case "lista" -> {
                ConfigurationSection sec = getConfig().getConfigurationSection("tryby");
                if (sec == null || sec.getKeys(false).isEmpty()) {
                    s.sendMessage(ChatColor.YELLOW + "Brak utworzonych trybow.");
                } else {
                    s.sendMessage(ChatColor.GREEN + "Tryby: " + ChatColor.WHITE + String.join(", ", sec.getKeys(false)));
                }
            }
            case "tp" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Tylko gracze."); return true; }
                if (args.length < 2) { s.sendMessage(ChatColor.RED + "Uzycie: /greencode-lobby tp <nazwa>"); return true; }
                String world = getConfig().getString("tryby." + args[1].toLowerCase());
                if (world == null) { p.sendMessage(ChatColor.RED + "Nie ma takiego trybu."); return true; }
                teleportTo(p, world);
            }
            case "kompas" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Tylko gracze."); return true; }
                p.getInventory().addItem(createCompass());
                p.sendMessage(ChatColor.GREEN + "Dostales kompas. Kliknij PPM, aby wybrac tryb.");
            }
            case "kompas-usun" -> {
                if (!(s instanceof Player p)) { s.sendMessage("Tylko gracze."); return true; }
                Inventory inv = p.getInventory();
                for (int i = 0; i < inv.getSize(); i++) {
                    if (isCompass(inv.getItem(i))) inv.setItem(i, null);
                }
                p.sendMessage(ChatColor.YELLOW + "Usunieto kompas z ekwipunku.");
            }
            default -> sendHelp(s);
        }
        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage(ChatColor.GREEN + "=== GreenCodeLobby ===");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby stworz <nazwa> " + ChatColor.GRAY + "- nowy tryb (komenda /<nazwa>)");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby usun <nazwa> " + ChatColor.GRAY + "- usuwa tryb i jego swiat");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby lista " + ChatColor.GRAY + "- lista trybow");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby tp <nazwa> " + ChatColor.GRAY + "- teleport do trybu");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby kompas " + ChatColor.GRAY + "- daje kompas wyboru trybu");
        s.sendMessage(ChatColor.YELLOW + "/greencode-lobby kompas-usun " + ChatColor.GRAY + "- usuwa kompas z ekwipunku");
    }

    // ===================== TRYBY =====================

    private void createMode(CommandSender s, String name) {
        if (!name.matches("[a-z0-9]{2,16}")) {
            s.sendMessage(ChatColor.RED + "Nazwa: tylko male litery i cyfry, 2-16 znakow.");
            return;
        }
        if (getConfig().contains("tryby." + name)) {
            s.sendMessage(ChatColor.RED + "Tryb o tej nazwie juz istnieje.");
            return;
        }
        CommandMap map = commandMap();
        if (map == null || map.getCommand(name) != null) {
            s.sendMessage(ChatColor.RED + "Ta nazwa jest zajeta przez inna komende.");
            return;
        }

        String worldName = WORLD_PREFIX + name;
        World world = createVoidWorld(worldName);
        if (world == null) {
            s.sendMessage(ChatColor.RED + "Nie udalo sie stworzyc swiata.");
            return;
        }

        getConfig().set("tryby." + name, worldName);
        saveConfig();
        registerModeCommand(name, worldName);

        s.sendMessage(ChatColor.GREEN + "Stworzono tryb '" + name + "'. Wpisz /" + name + ", aby tam wejsc.");
    }

    private void removeMode(CommandSender s, String name) {
        String worldName = getConfig().getString("tryby." + name);
        if (worldName == null) {
            s.sendMessage(ChatColor.RED + "Nie ma takiego trybu.");
            return;
        }

        ModeCommand mc = registered.remove(name);
        CommandMap map = commandMap();
        if (mc != null && map != null) mc.unregister(map);

        getConfig().set("tryby." + name, null);
        saveConfig();

        World world = Bukkit.getWorld(worldName);
        if (world != null) {
            World fallback = Bukkit.getWorlds().get(0);
            for (Player p : world.getPlayers()) {
                p.teleport(fallback.getSpawnLocation());
                p.sendMessage(ChatColor.YELLOW + "Tryb zostal usuniety, przeniesiono Cie na spawn.");
            }
            Bukkit.unloadWorld(world, false);
        }
        deleteFolder(new File(Bukkit.getWorldContainer(), worldName));
        updateCommandsForAll();

        s.sendMessage(ChatColor.GREEN + "Usunieto tryb '" + name + "'.");
    }

    private void registerModeCommand(String name, String worldName) {
        CommandMap map = commandMap();
        if (map == null) return;
        ModeCommand mc = new ModeCommand(this, name, worldName);
        map.register(getName().toLowerCase(), mc);
        registered.put(name, mc);
        updateCommandsForAll();
    }

    private World createVoidWorld(String worldName) {
        World existing = Bukkit.getWorld(worldName);
        if (existing != null) return existing;

        WorldCreator creator = new WorldCreator(worldName);
        creator.generator(new VoidGenerator());
        creator.generateStructures(false);
        World world = creator.createWorld();

        if (world != null) {
            // Platforma na srodku, zeby gracz nie spadal w pustke
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    world.getBlockAt(x, 63, z).setType(Material.STONE);
                }
            }
            world.setSpawnLocation(0, 64, 0);
        }
        return world;
    }

    void teleportTo(Player p, String worldName) {
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            p.sendMessage(ChatColor.RED + "Swiat tego trybu nie istnieje.");
            return;
        }
        p.teleport(world.getSpawnLocation());
    }

    // ===================== KOMPAS I MENU =====================

    private ItemStack createCompass() {
        ItemStack item = new ItemStack(Material.COMPASS);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GREEN + "Wybor trybu");
        meta.getPersistentDataContainer().set(compassKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isCompass(ItemStack item) {
        return item != null
                && item.getType() == Material.COMPASS
                && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(compassKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onCompassUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isCompass(e.getItem())) return;
        e.setCancelled(true);
        openModeMenu(e.getPlayer());
    }

    private void openModeMenu(Player p) {
        Inventory inv = Bukkit.createInventory(new MenuHolder(), 27, ChatColor.DARK_GREEN + "Wybierz tryb");
        ConfigurationSection sec = getConfig().getConfigurationSection("tryby");
        int slot = 0;
        if (sec != null) {
            for (String name : sec.getKeys(false)) {
                if (slot >= inv.getSize()) break;
                ItemStack item = new ItemStack(Material.GRASS_BLOCK);
                ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(ChatColor.GREEN + name);
                item.setItemMeta(meta);
                inv.setItem(slot++, item);
            }
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof MenuHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack item = e.getCurrentItem();
        if (item == null || !item.hasItemMeta()) return;

        String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());
        String worldName = getConfig().getString("tryby." + name);
        if (worldName != null) {
            p.closeInventory();
            teleportTo(p, worldName);
        }
    }

    // ===================== POMOCNICZE =====================

    private CommandMap commandMap() {
        try {
            Method m = Bukkit.getServer().getClass().getMethod("getCommandMap");
            return (CommandMap) m.invoke(Bukkit.getServer());
        } catch (ReflectiveOperationException ex) {
            getLogger().severe("Nie udalo sie pobrac CommandMap: " + ex.getMessage());
            return null;
        }
    }

    private void updateCommandsForAll() {
        for (Player p : Bukkit.getOnlinePlayers()) p.updateCommands();
    }

    private void deleteFolder(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteFolder(child);
        }
        file.delete();
    }

    // ===================== KLASY POMOCNICZE =====================

    /** Komenda tworzona dynamicznie dla kazdego trybu. */
    static class ModeCommand extends Command {
        private final LobbyPlugin plugin;
        private final String worldName;

        ModeCommand(LobbyPlugin plugin, String name, String worldName) {
            super(name);
            this.plugin = plugin;
            this.worldName = worldName;
            setDescription("Teleport do trybu " + name);
            setUsage("/" + name);
        }

        @Override
        public boolean execute(CommandSender sender, String label, String[] args) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Tylko gracze moga uzywac tej komendy.");
                return true;
            }
            plugin.teleportTo(p, worldName);
            return true;
        }
    }

    /** Pusty generator swiata (sama pustka). */
    static class VoidGenerator extends ChunkGenerator {
        @Override
        public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
            return createChunkData(world);
        }
    }

    /** Oznacza otwarte menu, zeby odroznic je od innych ekwipunkow. */
    static class MenuHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
