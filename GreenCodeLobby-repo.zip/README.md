# GreenCodeLobby

Budowanie jara:
1. Zainstaluj JDK 21 i Maven (albo użyj IntelliJ IDEA).
2. W tym folderze uruchom: mvn clean package
3. Gotowy plik: target/GreenCodeLobby-1.0.jar, wrzuć go do plugins/ na serwerze (Paper 1.21.11).

Komendy: /greencode-lobby stworz <nazwa>, usun, lista, tp, kompas, kompas-usun
