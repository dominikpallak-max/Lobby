package pl.askalki;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class AskalkiClient implements ClientModInitializer {
    // jak daleko InstantTaking szuka itemow (kratki)
    private static final double INSTANT_RANGE = 8.0;

    private long lastQuick = 0;
    private boolean keysHeld = false;

    @Override
    public void onInitializeClient() {
        AskalkiConfig.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("askalki").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    // otwieramy w nastepnym ticku, zeby czat nie zamknal menu
                    mc.send(() -> mc.setScreen(new AskalkiScreen()));
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        AskalkiConfig c = AskalkiConfig.get();

        if (p == null || mc.world == null || mc.currentScreen != null) {
            release(mc);
            return;
        }

        // --- FastWalkToDropSkalka: sprint do itemu (bez skakania) ---
        if (c.fastWalk) {
            Vec3d target = findWalkTarget(mc, p, c);
            if (target != null) {
                double dx = target.x - p.getX();
                double dz = target.z - p.getZ();
                if (Math.sqrt(dx * dx + dz * dz) < 0.3) {
                    release(mc); // jestesmy na miejscu
                    return;
                }
                face(p, target);
                mc.options.forwardKey.setPressed(true);
                mc.options.sprintKey.setPressed(true);
                mc.options.jumpKey.setPressed(false);
                keysHeld = true;
                return;
            }
        }

        release(mc);

        // --- InstantTaking: dash do itemu co X ms/s, tez gdy item jest w powietrzu ---
        if (c.instantTaking) {
            long now = System.currentTimeMillis();
            if (now - lastQuick < c.intervalMs) return;
            ItemEntity e = nearest(mc, p, INSTANT_RANGE);
            if (e == null) return;
            double dx = e.getX() - p.getX();
            double dy = e.getY() - p.getY();
            double dz = e.getZ() - p.getZ();
            double hlen = Math.sqrt(dx * dx + dz * dz);
            if (hlen < 0.05 && dy <= 0.5) return;
            lastQuick = now;
            Vec3d v = p.getVelocity();
            double vx = hlen > 0.05 ? dx / hlen * 0.9 : 0;
            double vz = hlen > 0.05 ? dz / hlen * 0.9 : 0;
            // item wyzej (np. leci w powietrzu) -> podskocz w jego strone
            double vy = dy > 0.5 ? Math.min(0.5, 0.2 + dy * 0.3) : v.y;
            p.setVelocity(vx, vy, vz);
        }
    }

    private void release(MinecraftClient mc) {
        if (!keysHeld) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        keysHeld = false;
    }

    private ItemEntity nearest(MinecraftClient mc, ClientPlayerEntity p, double range) {
        Box box = p.getBoundingBox().expand(range);
        List<ItemEntity> items = mc.world.getEntitiesByClass(ItemEntity.class, box,
                e -> e.isAlive() && !e.getStack().isEmpty());
        ItemEntity best = null;
        double bestDist = range * range;
        for (ItemEntity e : items) {
            double d = p.squaredDistanceTo(e);
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    /** Punkt do ktorego biec: item albo (opcjonalnie) miejsce jego ladowania. Null jesli poza dystansem. */
    private Vec3d findWalkTarget(MinecraftClient mc, ClientPlayerEntity p, AskalkiConfig c) {
        double range = c.walkRange;
        double search = c.walkToLanding ? range + 24 : range;
        Box box = p.getBoundingBox().expand(search);
        List<ItemEntity> items = mc.world.getEntitiesByClass(ItemEntity.class, box,
                e -> e.isAlive() && !e.getStack().isEmpty());
        Vec3d best = null;
        double bestDist = range * range;
        for (ItemEntity e : items) {
            Vec3d point = (c.walkToLanding && !e.isOnGround())
                    ? predictLanding(mc, e)
                    : new Vec3d(e.getX(), e.getY(), e.getZ());
            double dx = point.x - p.getX();
            double dy = point.y - p.getY();
            double dz = point.z - p.getZ();
            double d = dx * dx + dy * dy + dz * dz;
            if (d <= bestDist) {
                bestDist = d;
                best = point;
            }
        }
        return best;
    }

    /** Symulacja fizyki itemu (grawitacja 0.04, opor 0.98) - zwraca miejsce ladowania. */
    private Vec3d predictLanding(MinecraftClient mc, ItemEntity e) {
        double x = e.getX(), y = e.getY(), z = e.getZ();
        Vec3d vel = e.getVelocity();
        double vx = vel.x, vy = vel.y, vz = vel.z;
        double hw = e.getWidth() / 2.0;
        double h = e.getHeight();
        for (int i = 0; i < 120; i++) {
            vy -= 0.04;
            double nx = x + vx;
            if (!free(mc, nx, y, z, hw, h)) {
                vx = 0;
                nx = x;
            }
            double nz = z + vz;
            if (!free(mc, nx, y, nz, hw, h)) {
                vz = 0;
                nz = z;
            }
            double ny = y + vy;
            if (!free(mc, nx, ny, nz, hw, h)) {
                if (vy < 0) return new Vec3d(nx, y, nz); // wyladowal
                vy = 0;
                ny = y;
            }
            x = nx;
            y = ny;
            z = nz;
            vx *= 0.98;
            vy *= 0.98;
            vz *= 0.98;
        }
        return new Vec3d(x, y, z);
    }

    private boolean free(MinecraftClient mc, double x, double y, double z, double hw, double h) {
        return mc.world.isSpaceEmpty(new Box(x - hw, y, z - hw, x + hw, y + h, z + hw));
    }

    // natychmiastowe nakierowanie kamery na punkt
    private void face(ClientPlayerEntity p, Vec3d t) {
        double dx = t.x - p.getX();
        double dy = t.y - p.getEyeY();
        double dz = t.z - p.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 180.0 / Math.PI);
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -89.0f, 89.0f));
    }
}
