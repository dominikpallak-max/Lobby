package pl.askalki;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class AskalkiConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("askalki.json");
    private static AskalkiConfig instance = new AskalkiConfig();

    // InstantTaking
    public boolean instantTaking = false;
    public long intervalMs = 250;
    public boolean intervalInSeconds = false;

    // FastWalkToDropSkalka
    public boolean fastWalk = false;
    public double walkRange = 5.0;
    public boolean walkToLanding = false;

    public static AskalkiConfig get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                AskalkiConfig c = GSON.fromJson(Files.readString(FILE), AskalkiConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }
}
