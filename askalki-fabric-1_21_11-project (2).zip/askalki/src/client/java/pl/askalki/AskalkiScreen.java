package pl.askalki;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;

public class AskalkiScreen extends Screen {
    private final AskalkiConfig cfg = AskalkiConfig.get();
    private ValueSlider timeSlider;
    private ValueSlider rangeSlider;
    private ButtonWidget unitButton;
    private ButtonWidget landingButton;

    public AskalkiScreen() {
        super(Text.literal("Askalki"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 80;

        // --- InstantTaking ---
        addDrawableChild(ButtonWidget.builder(instantLabel(), b -> {
            cfg.instantTaking = !cfg.instantTaking;
            b.setMessage(instantLabel());
            refreshActive();
        }).dimensions(cx - 100, y, 200, 20).build());

        final boolean sec = cfg.intervalInSeconds;
        double min = sec ? 0.1 : 1;
        double max = sec ? 10 : 1000;
        double step = sec ? 0.1 : 1;
        double cur = sec ? cfg.intervalMs / 1000.0 : cfg.intervalMs;
        timeSlider = new ValueSlider(cx - 100, y + 24, 140, 20, min, max, step, cur,
                v -> Text.literal("Czas: " + fmt(v) + (sec ? " s" : " ms")),
                v -> cfg.intervalMs = Math.max(1, Math.round(sec ? v * 1000.0 : v)));
        addDrawableChild(timeSlider);

        unitButton = ButtonWidget.builder(Text.literal(sec ? "sekundy" : "ms"), b -> {
            cfg.intervalInSeconds = !cfg.intervalInSeconds;
            clearAndInit();
        }).dimensions(cx + 44, y + 24, 56, 20).build();
        addDrawableChild(unitButton);

        // --- FastWalkToDropSkalka ---
        addDrawableChild(ButtonWidget.builder(walkLabel(), b -> {
            cfg.fastWalk = !cfg.fastWalk;
            b.setMessage(walkLabel());
            refreshActive();
        }).dimensions(cx - 100, y + 60, 200, 20).build());

        rangeSlider = new ValueSlider(cx - 100, y + 84, 200, 20, 1, 32, 0.5, cfg.walkRange,
                v -> Text.literal("Dystans: " + fmt(v) + " kratek"),
                v -> cfg.walkRange = v);
        addDrawableChild(rangeSlider);

        landingButton = ButtonWidget.builder(landingLabel(), b -> {
            cfg.walkToLanding = !cfg.walkToLanding;
            b.setMessage(landingLabel());
        }).dimensions(cx - 100, y + 108, 200, 20).build();
        addDrawableChild(landingButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(cx - 100, y + 144, 200, 20).build());

        refreshActive();
    }

    private void refreshActive() {
        timeSlider.active = cfg.instantTaking;
        unitButton.active = cfg.instantTaking;
        rangeSlider.active = cfg.fastWalk;
        landingButton.active = cfg.fastWalk;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int y = this.height / 2 - 80;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, y - 20, 0xFFFFFF);
    }

    @Override
    public void removed() {
        AskalkiConfig.save();
    }

    private Text instantLabel() {
        return Text.literal("InstantTaking: " + (cfg.instantTaking ? "ON" : "OFF"));
    }

    private Text walkLabel() {
        return Text.literal("FastWalkToDropSkalka: " + (cfg.fastWalk ? "ON" : "OFF"));
    }

    private Text landingLabel() {
        return Text.literal("Biegnij na miejsce ladowania: " + (cfg.walkToLanding ? "ON" : "OFF"));
    }

    private static String fmt(double v) {
        if (v == Math.rint(v)) return String.valueOf((long) v);
        return String.format(Locale.ROOT, "%.1f", v);
    }

    /** Suwak z zakresem min..max i krokiem step. */
    private static class ValueSlider extends SliderWidget {
        private final double min, max, step;
        private final DoubleFunction<Text> label;
        private final DoubleConsumer onChange;

        ValueSlider(int x, int y, int w, int h, double min, double max, double step, double current,
                    DoubleFunction<Text> label, DoubleConsumer onChange) {
            super(x, y, w, h, Text.empty(), (Math.max(min, Math.min(max, current)) - min) / (max - min));
            this.min = min;
            this.max = max;
            this.step = step;
            this.label = label;
            this.onChange = onChange;
            updateMessage();
        }

        private double real() {
            double v = min + this.value * (max - min);
            v = Math.round(v / step) * step;
            return Math.max(min, Math.min(max, v));
        }

        @Override
        protected void updateMessage() {
            setMessage(label.apply(real()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(real());
        }
    }
}
