ASKALKI - mod Fabric 1.21.11 (tylko klient)

/askalki -> otwiera menu (GUI):
 - InstantTaking (ON/OFF) + suwak czasu (przycisk obok przelacza ms / sekundy):
   co tyle czasu dash w strone najblizszego itemu (do 8 kratek), tez gdy item jest w powietrzu
 - FastWalkToDropSkalka (ON/OFF) + suwak dystansu (np. 5 kratek):
   gdy item jest w tym dystansie - sprint do niego (bez skakania); dalej - nic nie robi
 - Biegnij na miejsce ladowania (ON/OFF): przewiduje gdzie wyladuje wyrzucony item i biegnie tam
 - Ustawienia zapisuja sie w config/askalki.json

JAK ZROBIC JAR (jedna z opcji):
 1) Zainstaluj JDK 21 + Gradle 9.2.1, w folderze projektu wpisz:  gradle build
    Gotowy plik: build/libs/askalki-1.0.0.jar  (NIE ten z -sources)
 2) Otworz folder w IntelliJ IDEA -> zakladka Gradle -> Tasks -> build -> build
 3) Wrzuc projekt na GitHub - zakladka Actions zbuduje jar (artifact askalki-jar)

Jar wrzucasz do .minecraft/mods razem z Fabric API.
Jesli Gradle krzyczy o wersje - wygeneruj aktualne na https://fabricmc.net/develop
i popraw gradle.properties (yarn_mappings, loader_version, fabric_api_version).
