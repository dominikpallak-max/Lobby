package pl.askalki;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class AskalkiClient implements ClientModInitializer {
    private long lastQuick = 0;
    private boolean keysHeld = false;

    @Override
    public void onInitializeClient() {
        AskalkiConfig.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                registerCommands(dispatcher));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    // ---------- KOMENDY ----------
    private void registerCommands(CommandDispatcher<FabricClientCommandSource> d) {
        AskalkiConfig c = AskalkiConfig.get();

        d.register(ClientCommandManager.literal("askalki")
                .executes(ctx -> openMenu())
                .then(ClientCommandManager.literal("menu").executes(ctx -> openMenu()))
                .then(ClientCommandManager.literal("status").executes(ctx -> {
                    status(ctx.getSource());
                    return 1;
                }))
                .then(ClientCommandManager.literal("quick")
                        .executes(ctx -> {
                            c.quickPickup = !c.quickPickup;
                            AskalkiConfig.save();
                            ctx.getSource().sendFeedback(Text.literal("Szybkie podnoszenie: " + onOff(c.quickPickup)));
                            return 1;
                        })
                        .then(onOffArg(ctx -> c.quickPickup, v -> c.quickPickup = v, "Szybkie podnoszenie")))
                .then(ClientCommandManager.literal("walk")
                        .executes(ctx -> {
                            c.autoWalk = !c.autoWalk;
                            AskalkiConfig.save();
                            ctx.getSource().sendFeedback(Text.literal("Chodzenie do itemu: " + onOff(c.autoWalk)));
                            return 1;
                        })
                        .then(onOffArg(ctx -> c.autoWalk, v -> c.autoWalk = v, "Chodzenie do itemu")))
                .then(ClientCommandManager.literal("interval")
                        .then(ClientCommandManager.argument("wartosc", DoubleArgumentType.doubleArg(0.001))
                                .executes(ctx -> setInterval(ctx.getSource(),
                                        DoubleArgumentType.getDouble(ctx, "wartosc"), c.intervalInSeconds))
                                .then(ClientCommandManager.literal("ms").executes(ctx -> setInterval(ctx.getSource(),
                                        DoubleArgumentType.getDouble(ctx, "wartosc"), false)))
                                .then(ClientCommandManager.literal("s").executes(ctx -> setInterval(ctx.getSource(),
                                        DoubleArgumentType.getDouble(ctx, "wartosc"), true)))))
                .then(ClientCommandManager.literal("range")
                        .then(ClientCommandManager.argument("kratki", DoubleArgumentType.doubleArg(0.5, 64.0))
                                .executes(ctx -> {
                                    c.range = DoubleArgumentType.getDouble(ctx, "kratki");
                                    AskalkiConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal("Zasieg: " + c.range + " kratek"));
                                    return 1;
                                }))));
    }

    private interface BoolSetter { void set(boolean v); }
    private interface BoolGetter { boolean get(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> ctx); }

    private com.mojang.brigadier.builder.RequiredArgumentBuilder<FabricClientCommandSource, String> onOffArg(
            BoolGetter ignored, BoolSetter setter, String label) {
        return ClientCommandManager.argument("stan", StringArgumentType.word())
                .suggests((ctx, b) -> CommandSource.suggestMatching(List.of("on", "off"), b))
                .executes(ctx -> {
                    String a = StringArgumentType.getString(ctx, "stan").toLowerCase();
                    boolean v;
                    if (a.equals("on") || a.equals("wl") || a.equals("true") || a.equals("1")) v = true;
                    else if (a.equals("off") || a.equals("wyl") || a.equals("false") || a.equals("0")) v = false;
                    else {
                        ctx.getSource().sendError(Text.literal("Uzyj: on / off"));
                        return 0;
                    }
                    setter.set(v);
                    AskalkiConfig.save();
                    ctx.getSource().sendFeedback(Text.literal(label + ": " + onOff(v)));
                    return 1;
                });
    }

    private int setInterval(FabricClientCommandSource src, double value, boolean seconds) {
        AskalkiConfig c = AskalkiConfig.get();
        c.intervalInSeconds = seconds;
        c.intervalMs = Math.max(1, Math.round(seconds ? value * 1000.0 : value));
        AskalkiConfig.save();
        src.sendFeedback(Text.literal("Interwal: " + c.intervalMs + " ms"));
        return 1;
    }

    private void status(FabricClientCommandSource src) {
        AskalkiConfig c = AskalkiConfig.get();
        src.sendFeedback(Text.literal("Askalki | szybkie podnoszenie: " + onOff(c.quickPickup)
                + " | chodzenie: " + onOff(c.autoWalk)
                + " | interwal: " + c.intervalMs + " ms"
                + " | zasieg: " + c.range));
    }

    private int openMenu() {
        MinecraftClient mc = MinecraftClient.getInstance();
        // otwieramy w nastepnym ticku, zeby czat nie zamknal menu
        mc.send(() -> mc.setScreen(new AskalkiScreen()));
        return 1;
    }

    private static String onOff(boolean b) {
        return b ? "WL" : "WYL";
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        AskalkiConfig c = AskalkiConfig.get();

        if (p == null || mc.world == null || mc.currentScreen != null) {
            release(mc);
            return;
        }

        if (c.autoWalk) {
            ItemEntity target = nearest(mc, p, c.range);
            if (target == null) {
                release(mc);
                return;
            }
            face(p, target);
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
            keysHeld = true;
            return;
        }

        release(mc);

        if (c.quickPickup) {
            long now = System.currentTimeMillis();
            if (now - lastQuick < c.intervalMs) return;
            ItemEntity target = nearest(mc, p, c.range);
            if (target == null) return;
            double dx = target.getX() - p.getX();
            double dz = target.getZ() - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.05) return;
            lastQuick = now;
            Vec3d v = p.getVelocity();
            p.setVelocity(dx / len * 0.9, v.y, dz / len * 0.9);
        }
    }

    private void release(MinecraftClient mc) {
        if (!keysHeld) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        keysHeld = false;
    }

    private ItemEntity nearest(MinecraftClient mc, ClientPlayerEntity p, double range) {
        Box box = p.getBoundingBox().expand(range);
        List<ItemEntity> items = mc.world.getEntitiesByClass(ItemEntity.class, box,
                e -> e.isAlive() && !e.getStack().isEmpty());
        ItemEntity best = null;
        double bestDist = range * range;
        for (ItemEntity e : items) {
            double d = p.squaredDistanceTo(e);
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    // natychmiastowe nakierowanie kamery na item
    private void face(ClientPlayerEntity p, ItemEntity e) {
        double dx = e.getX() - p.getX();
        double dy = e.getY() - p.getEyeY();
        double dz = e.getZ() - p.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 180.0 / Math.PI);
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -89.0f, 89.0f));
    }
}
