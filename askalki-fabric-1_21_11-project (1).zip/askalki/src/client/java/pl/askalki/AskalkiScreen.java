package pl.askalki;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.Locale;

public class AskalkiScreen extends Screen {
    private final AskalkiConfig cfg = AskalkiConfig.get();
    private TextFieldWidget intervalField;
    private TextFieldWidget rangeField;

    public AskalkiScreen() {
        super(Text.literal("Askalki"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 85;

        addDrawableChild(ButtonWidget.builder(quickLabel(), b -> {
            cfg.quickPickup = !cfg.quickPickup;
            b.setMessage(quickLabel());
        }).dimensions(cx - 100, y, 200, 20).build());

        intervalField = new TextFieldWidget(this.textRenderer, cx - 100, y + 45, 100, 20, Text.literal("Interwal"));
        intervalField.setText(formatInterval());
        intervalField.setChangedListener(s -> {
            try {
                double v = Double.parseDouble(s.trim().replace(',', '.'));
                long ms = Math.round(cfg.intervalInSeconds ? v * 1000.0 : v);
                cfg.intervalMs = Math.max(1, ms);
            } catch (NumberFormatException ignored) {
            }
        });
        addDrawableChild(intervalField);

        addDrawableChild(ButtonWidget.builder(unitLabel(), b -> {
            cfg.intervalInSeconds = !cfg.intervalInSeconds;
            b.setMessage(unitLabel());
            intervalField.setText(formatInterval());
        }).dimensions(cx + 4, y + 45, 96, 20).build());

        addDrawableChild(ButtonWidget.builder(walkLabel(), b -> {
            cfg.autoWalk = !cfg.autoWalk;
            b.setMessage(walkLabel());
        }).dimensions(cx - 100, y + 85, 200, 20).build());

        rangeField = new TextFieldWidget(this.textRenderer, cx - 100, y + 130, 200, 20, Text.literal("Zasieg"));
        rangeField.setText(trim(cfg.range));
        rangeField.setChangedListener(s -> {
            try {
                double v = Double.parseDouble(s.trim().replace(',', '.'));
                cfg.range = Math.max(0.5, Math.min(64.0, v));
            } catch (NumberFormatException ignored) {
            }
        });
        addDrawableChild(rangeField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(cx - 100, y + 165, 200, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int y = this.height / 2 - 85;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, y - 20, 0xFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("Co ile podnosic (interwal):"), cx - 100, y + 33, 0xAAAAAA);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("Zasieg wykrywania itemu (kratki):"), cx - 100, y + 118, 0xAAAAAA);
    }

    @Override
    public void removed() {
        AskalkiConfig.save();
    }

    private Text quickLabel() {
        return Text.literal("Szybkie podnoszenie: " + (cfg.quickPickup ? "WL" : "WYL"));
    }

    private Text walkLabel() {
        return Text.literal("Chodz do najblizszego itemu: " + (cfg.autoWalk ? "WL" : "WYL"));
    }

    private Text unitLabel() {
        return Text.literal("Jednostka: " + (cfg.intervalInSeconds ? "sekundy" : "ms"));
    }

    private String formatInterval() {
        return trim(cfg.intervalInSeconds ? cfg.intervalMs / 1000.0 : cfg.intervalMs);
    }

    private static String trim(double v) {
        if (v == Math.rint(v)) return String.valueOf((long) v);
        return String.format(Locale.ROOT, "%.3f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}
