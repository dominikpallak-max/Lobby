package pl.askalki;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class AskalkiClient implements ClientModInitializer {
    private long lastQuick = 0;
    private boolean keysHeld = false;

    @Override
    public void onInitializeClient() {
        AskalkiConfig.load();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("askalki").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    // otwieramy w nastepnym ticku, zeby czat nie zamknal menu
                    mc.send(() -> mc.setScreen(new AskalkiScreen()));
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        AskalkiConfig c = AskalkiConfig.get();

        if (p == null || mc.world == null || mc.currentScreen != null) {
            release(mc);
            return;
        }

        if (c.autoWalk) {
            ItemEntity target = nearest(mc, p, c.range);
            if (target == null) {
                release(mc);
                return;
            }
            face(p, target);
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
            keysHeld = true;
            return;
        }

        release(mc);

        if (c.quickPickup) {
            long now = System.currentTimeMillis();
            if (now - lastQuick < c.intervalMs) return;
            ItemEntity target = nearest(mc, p, c.range);
            if (target == null) return;
            double dx = target.getX() - p.getX();
            double dz = target.getZ() - p.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.05) return;
            lastQuick = now;
            Vec3d v = p.getVelocity();
            p.setVelocity(dx / len * 0.9, v.y, dz / len * 0.9);
        }
    }

    private void release(MinecraftClient mc) {
        if (!keysHeld) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        keysHeld = false;
    }

    private ItemEntity nearest(MinecraftClient mc, ClientPlayerEntity p, double range) {
        Box box = p.getBoundingBox().expand(range);
        List<ItemEntity> items = mc.world.getEntitiesByClass(ItemEntity.class, box,
                e -> e.isAlive() && !e.getStack().isEmpty());
        ItemEntity best = null;
        double bestDist = range * range;
        for (ItemEntity e : items) {
            double d = p.squaredDistanceTo(e);
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    // natychmiastowe nakierowanie kamery na item
    private void face(ClientPlayerEntity p, ItemEntity e) {
        double dx = e.getX() - p.getX();
        double dy = e.getY() - p.getEyeY();
        double dz = e.getZ() - p.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 180.0 / Math.PI);
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -89.0f, 89.0f));
    }
}
